"use client";

import { useState } from 'react';
import { TiptapEditor } from '@/components/editor/tiptap-editor';
import { NotesSystem } from '@/components/notes/notes-system';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  PenTool,
  StickyNote,
  Save,
  Download,
  Settings,
  Eye,
  EyeOff,
  Moon,
  Sun,
  Maximize,
  Minimize,
  Clock,
  Target,
  BookOpen,
} from 'lucide-react';
import { cn } from '@/lib/utils';

export default function WritingStudio() {
  const [content, setContent] = useState('');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isDisturbMode, setIsDisturbMode] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [wordCount, setWordCount] = useState(0);
  const [targetWords, setTargetWords] = useState(2000);
  const [writingTime, setWritingTime] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  const handleContentChange = (newContent: string) => {
    setContent(newContent);
    // Simple word count calculation
    const words = newContent.replace(/<[^>]*>/g, '').trim().split(/\s+/).filter(word => word.length > 0);
    setWordCount(words.length);
  };

  const toggleDisturbMode = () => {
    setIsDisturbMode(!isDisturbMode);
    if (!isDisturbMode) {
      setIsFullscreen(true);
    }
  };

  const saveDocument = () => {
    // Implement save functionality
    console.log('Saving document...');
  };

  const exportDocument = () => {
    // Implement export functionality
    const element = document.createElement('a');
    const file = new Blob([content], { type: 'text/html' });
    element.href = URL.createObjectURL(file);
    element.download = 'document.html';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  if (isDisturbMode) {
    return (
      <div className={cn(
        "fixed inset-0 z-50 bg-white",
        isDarkMode && "bg-gray-900"
      )}>
        {/* Minimal Header for Distraction-Free Mode */}
        <div className="absolute top-4 right-4 z-10 flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsDarkMode(!isDarkMode)}
            className={isDarkMode ? "text-white hover:bg-gray-800" : ""}
          >
            {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleDisturbMode}
            className={isDarkMode ? "text-white hover:bg-gray-800" : ""}
          >
            <EyeOff className="h-4 w-4" />
          </Button>
        </div>

        {/* Progress Bar */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gray-200">
          <div 
            className="h-full bg-purple-600 transition-all duration-300"
            style={{ width: `${Math.min((wordCount / targetWords) * 100, 100)}%` }}
          />
        </div>

        {/* Editor */}
        <div className={cn(
          "h-full pt-8",
          isDarkMode && "bg-gray-900"
        )}>
          <TiptapEditor
            content={content}
            onChange={handleContentChange}
            isFullscreen={true}
            placeholder="Focus on your writing. Let the words flow..."
          />
        </div>

        {/* Word Count Footer */}
        <div className={cn(
          "absolute bottom-4 left-4 text-sm text-gray-500",
          isDarkMode && "text-gray-400"
        )}>
          {wordCount} / {targetWords} words
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Writing Studio</h1>
          <p className="text-gray-600 mt-1">Your creative writing workspace</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" onClick={saveDocument}>
            <Save className="h-4 w-4 mr-2" />
            Save
          </Button>
          <Button variant="outline" onClick={exportDocument}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button onClick={toggleDisturbMode}>
            <Eye className="h-4 w-4 mr-2" />
            Focus Mode
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Word Count</CardTitle>
            <PenTool className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{wordCount.toLocaleString()}</div>
            <div className="text-xs text-gray-600">
              {Math.round((wordCount / targetWords) * 100)}% of target
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Target</CardTitle>
            <Target className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{targetWords.toLocaleString()}</div>
            <div className="text-xs text-gray-600">words today</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Writing Time</CardTitle>
            <Clock className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.floor(writingTime / 60)}:{(writingTime % 60).toString().padStart(2, '0')}
            </div>
            <div className="text-xs text-gray-600">minutes today</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pages</CardTitle>
            <BookOpen className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Math.ceil(wordCount / 250)}</div>
            <div className="text-xs text-gray-600">estimated pages</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="editor" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="editor" className="flex items-center space-x-2">
            <PenTool className="h-4 w-4" />
            <span>Editor</span>
          </TabsTrigger>
          <TabsTrigger value="notes" className="flex items-center space-x-2">
            <StickyNote className="h-4 w-4" />
            <span>Notes</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="editor" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Document Editor</CardTitle>
                <div className="flex items-center space-x-2">
                  <Badge variant="outline">
                    {wordCount} words
                  </Badge>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsFullscreen(!isFullscreen)}
                  >
                    {isFullscreen ? (
                      <Minimize className="h-4 w-4" />
                    ) : (
                      <Maximize className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <TiptapEditor
                content={content}
                onChange={handleContentChange}
                isFullscreen={isFullscreen}
                onToggleFullscreen={() => setIsFullscreen(!isFullscreen)}
                placeholder="Begin your story here..."
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notes">
          <NotesSystem />
        </TabsContent>
      </Tabs>
    </div>
  );
}