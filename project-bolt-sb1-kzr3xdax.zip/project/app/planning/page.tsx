"use client";

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar } from '@/components/ui/calendar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Calendar as CalendarIcon,
  Clock,
  Target,
  BookOpen,
  Users,
  MapPin,
  Lightbulb,
  Plus,
  Edit,
  Trash2,
  CheckCircle,
  Circle,
  AlertCircle,
  TrendingUp,
  FileText,
  Zap,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface Task {
  id: string;
  title: string;
  description: string;
  type: 'writing' | 'research' | 'editing' | 'marketing' | 'planning';
  priority: 'low' | 'medium' | 'high';
  status: 'todo' | 'in-progress' | 'completed';
  dueDate?: Date;
  projectId?: string;
  estimatedHours?: number;
  actualHours?: number;
  createdAt: Date;
}

interface Goal {
  id: string;
  title: string;
  description: string;
  type: 'daily' | 'weekly' | 'monthly' | 'yearly';
  target: number;
  current: number;
  unit: 'words' | 'pages' | 'chapters' | 'hours' | 'projects';
  deadline: Date;
  isActive: boolean;
  createdAt: Date;
}

interface Milestone {
  id: string;
  title: string;
  description: string;
  projectId: string;
  targetDate: Date;
  isCompleted: boolean;
  completedDate?: Date;
  tasks: string[];
  createdAt: Date;
}

const mockTasks: Task[] = [
  {
    id: '1',
    title: 'Write Chapter 5',
    description: 'Complete the confrontation scene between protagonist and antagonist',
    type: 'writing',
    priority: 'high',
    status: 'in-progress',
    dueDate: new Date('2024-02-01'),
    projectId: '1',
    estimatedHours: 4,
    actualHours: 2,
    createdAt: new Date('2024-01-15'),
  },
  {
    id: '2',
    title: 'Research Medieval Weapons',
    description: 'Research authentic medieval weapons for battle scenes',
    type: 'research',
    priority: 'medium',
    status: 'todo',
    dueDate: new Date('2024-01-30'),
    estimatedHours: 2,
    createdAt: new Date('2024-01-20'),
  },
];

const mockGoals: Goal[] = [
  {
    id: '1',
    title: 'Daily Word Count',
    description: 'Write 1000 words every day',
    type: 'daily',
    target: 1000,
    current: 750,
    unit: 'words',
    deadline: new Date('2024-12-31'),
    isActive: true,
    createdAt: new Date('2024-01-01'),
  },
  {
    id: '2',
    title: 'Complete Novel',
    description: 'Finish writing the first draft of my fantasy novel',
    type: 'yearly',
    target: 1,
    current: 0,
    unit: 'projects',
    deadline: new Date('2024-12-31'),
    isActive: true,
    createdAt: new Date('2024-01-01'),
  },
];

const mockMilestones: Milestone[] = [
  {
    id: '1',
    title: 'First Draft Complete',
    description: 'Complete the first draft of the novel',
    projectId: '1',
    targetDate: new Date('2024-06-30'),
    isCompleted: false,
    tasks: ['1', '2'],
    createdAt: new Date('2024-01-01'),
  },
];

const taskTypes = [
  { value: 'writing', label: 'Writing', icon: BookOpen, color: 'text-blue-600' },
  { value: 'research', label: 'Research', icon: FileText, color: 'text-green-600' },
  { value: 'editing', label: 'Editing', icon: Edit, color: 'text-purple-600' },
  { value: 'marketing', label: 'Marketing', icon: TrendingUp, color: 'text-orange-600' },
  { value: 'planning', label: 'Planning', icon: Target, color: 'text-pink-600' },
];

const priorityColors = {
  low: 'bg-gray-100 text-gray-800',
  medium: 'bg-yellow-100 text-yellow-800',
  high: 'bg-red-100 text-red-800',
};

const statusColors = {
  todo: 'bg-gray-100 text-gray-800',
  'in-progress': 'bg-blue-100 text-blue-800',
  completed: 'bg-green-100 text-green-800',
};

export default function PlanningPage() {
  const [tasks, setTasks] = useState<Task[]>(mockTasks);
  const [goals, setGoals] = useState<Goal[]>(mockGoals);
  const [milestones, setMilestones] = useState<Milestone[]>(mockMilestones);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [isCreatingTask, setIsCreatingTask] = useState(false);
  const [isCreatingGoal, setIsCreatingGoal] = useState(false);
  const [isCreatingMilestone, setIsCreatingMilestone] = useState(false);

  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    type: 'writing' as const,
    priority: 'medium' as const,
    dueDate: new Date(),
    estimatedHours: 1,
  });

  const [newGoal, setNewGoal] = useState({
    title: '',
    description: '',
    type: 'daily' as const,
    target: 1000,
    unit: 'words' as const,
    deadline: new Date(),
  });

  const [newMilestone, setNewMilestone] = useState({
    title: '',
    description: '',
    targetDate: new Date(),
  });

  const createTask = () => {
    const task: Task = {
      id: Date.now().toString(),
      ...newTask,
      status: 'todo',
      current: 0,
      createdAt: new Date(),
    };
    setTasks(prev => [task, ...prev]);
    setNewTask({
      title: '',
      description: '',
      type: 'writing',
      priority: 'medium',
      dueDate: new Date(),
      estimatedHours: 1,
    });
    setIsCreatingTask(false);
  };

  const createGoal = () => {
    const goal: Goal = {
      id: Date.now().toString(),
      ...newGoal,
      current: 0,
      isActive: true,
      createdAt: new Date(),
    };
    setGoals(prev => [goal, ...prev]);
    setNewGoal({
      title: '',
      description: '',
      type: 'daily',
      target: 1000,
      unit: 'words',
      deadline: new Date(),
    });
    setIsCreatingGoal(false);
  };

  const createMilestone = () => {
    const milestone: Milestone = {
      id: Date.now().toString(),
      ...newMilestone,
      projectId: '1',
      isCompleted: false,
      tasks: [],
      createdAt: new Date(),
    };
    setMilestones(prev => [milestone, ...prev]);
    setNewMilestone({
      title: '',
      description: '',
      targetDate: new Date(),
    });
    setIsCreatingMilestone(false);
  };

  const toggleTaskStatus = (taskId: string) => {
    setTasks(prev => prev.map(task => {
      if (task.id === taskId) {
        const newStatus = task.status === 'completed' ? 'todo' : 
                         task.status === 'todo' ? 'in-progress' : 'completed';
        return { ...task, status: newStatus };
      }
      return task;
    }));
  };

  const TaskCard = ({ task }: { task: Task }) => {
    const typeInfo = taskTypes.find(t => t.value === task.type);
    const TypeIcon = typeInfo?.icon || BookOpen;

    return (
      <Card className="hover:shadow-md transition-shadow">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={() => toggleTaskStatus(task.id)}
              >
                {task.status === 'completed' ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : task.status === 'in-progress' ? (
                  <AlertCircle className="h-4 w-4 text-blue-600" />
                ) : (
                  <Circle className="h-4 w-4 text-gray-400" />
                )}
              </Button>
              <CardTitle className={cn(
                "text-lg font-medium",
                task.status === 'completed' && "line-through text-gray-500"
              )}>
                {task.title}
              </CardTitle>
            </div>
            <div className="flex items-center space-x-2">
              <TypeIcon className={cn("h-4 w-4", typeInfo?.color)} />
              <Badge className={priorityColors[task.priority]}>
                {task.priority}
              </Badge>
            </div>
          </div>
          <CardDescription className="line-clamp-2">
            {task.description}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between text-sm text-gray-600">
            <div className="flex items-center space-x-4">
              <Badge className={statusColors[task.status]}>
                {task.status.replace('-', ' ')}
              </Badge>
              {task.dueDate && (
                <div className="flex items-center space-x-1">
                  <CalendarIcon className="h-3 w-3" />
                  <span>{task.dueDate.toLocaleDateString()}</span>
                </div>
              )}
            </div>
            {task.estimatedHours && (
              <div className="flex items-center space-x-1">
                <Clock className="h-3 w-3" />
                <span>{task.actualHours || 0}/{task.estimatedHours}h</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  const GoalCard = ({ goal }: { goal: Goal }) => {
    const progress = (goal.current / goal.target) * 100;
    
    return (
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-medium">{goal.title}</CardTitle>
            <Badge variant="outline">{goal.type}</Badge>
          </div>
          <CardDescription>{goal.description}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span>Progress</span>
              <span>{goal.current} / {goal.target} {goal.unit}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(progress, 100)}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>{Math.round(progress)}% complete</span>
              <div className="flex items-center space-x-1">
                <CalendarIcon className="h-3 w-3" />
                <span>Due {goal.deadline.toLocaleDateString()}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Planning</h1>
          <p className="text-gray-600 mt-1">Organize your writing projects and track your progress</p>
        </div>
        <div className="flex items-center space-x-2">
          <Dialog open={isCreatingTask} onOpenChange={setIsCreatingTask}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                New Task
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Task</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Title</Label>
                  <Input
                    value={newTask.title}
                    onChange={(e) => setNewTask(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Task title"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea
                    value={newTask.description}
                    onChange={(e) => setNewTask(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Task description"
                    rows={3}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Type</Label>
                    <Select
                      value={newTask.type}
                      onValueChange={(value: any) => setNewTask(prev => ({ ...prev, type: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {taskTypes.map(type => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Priority</Label>
                    <Select
                      value={newTask.priority}
                      onValueChange={(value: any) => setNewTask(prev => ({ ...prev, priority: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Due Date</Label>
                    <Input
                      type="date"
                      value={newTask.dueDate.toISOString().split('T')[0]}
                      onChange={(e) => setNewTask(prev => ({ ...prev, dueDate: new Date(e.target.value) }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Estimated Hours</Label>
                    <Input
                      type="number"
                      value={newTask.estimatedHours}
                      onChange={(e) => setNewTask(prev => ({ ...prev, estimatedHours: parseInt(e.target.value) }))}
                      min="1"
                    />
                  </div>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsCreatingTask(false)}>
                    Cancel
                  </Button>
                  <Button onClick={createTask}>Create Task</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <Dialog open={isCreatingGoal} onOpenChange={setIsCreatingGoal}>
            <DialogTrigger asChild>
              <Button>
                <Target className="h-4 w-4 mr-2" />
                New Goal
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Goal</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Title</Label>
                  <Input
                    value={newGoal.title}
                    onChange={(e) => setNewGoal(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Goal title"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea
                    value={newGoal.description}
                    onChange={(e) => setNewGoal(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Goal description"
                    rows={3}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Type</Label>
                    <Select
                      value={newGoal.type}
                      onValueChange={(value: any) => setNewGoal(prev => ({ ...prev, type: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                        <SelectItem value="yearly">Yearly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Unit</Label>
                    <Select
                      value={newGoal.unit}
                      onValueChange={(value: any) => setNewGoal(prev => ({ ...prev, unit: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="words">Words</SelectItem>
                        <SelectItem value="pages">Pages</SelectItem>
                        <SelectItem value="chapters">Chapters</SelectItem>
                        <SelectItem value="hours">Hours</SelectItem>
                        <SelectItem value="projects">Projects</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Target</Label>
                    <Input
                      type="number"
                      value={newGoal.target}
                      onChange={(e) => setNewGoal(prev => ({ ...prev, target: parseInt(e.target.value) }))}
                      min="1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Deadline</Label>
                    <Input
                      type="date"
                      value={newGoal.deadline.toISOString().split('T')[0]}
                      onChange={(e) => setNewGoal(prev => ({ ...prev, deadline: new Date(e.target.value) }))}
                    />
                  </div>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsCreatingGoal(false)}>
                    Cancel
                  </Button>
                  <Button onClick={createGoal}>Create Goal</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="tasks" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="goals">Goals</TabsTrigger>
          <TabsTrigger value="milestones">Milestones</TabsTrigger>
          <TabsTrigger value="calendar">Calendar</TabsTrigger>
        </TabsList>

        <TabsContent value="tasks" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tasks.map(task => (
              <TaskCard key={task.id} task={task} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="goals" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {goals.map(goal => (
              <GoalCard key={goal.id} goal={goal} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="milestones" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Project Milestones</h2>
            <Dialog open={isCreatingMilestone} onOpenChange={setIsCreatingMilestone}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  New Milestone
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Milestone</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Title</Label>
                    <Input
                      value={newMilestone.title}
                      onChange={(e) => setNewMilestone(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Milestone title"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Textarea
                      value={newMilestone.description}
                      onChange={(e) => setNewMilestone(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Milestone description"
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Target Date</Label>
                    <Input
                      type="date"
                      value={newMilestone.targetDate.toISOString().split('T')[0]}
                      onChange={(e) => setNewMilestone(prev => ({ ...prev, targetDate: new Date(e.target.value) }))}
                    />
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setIsCreatingMilestone(false)}>
                      Cancel
                    </Button>
                    <Button onClick={createMilestone}>Create Milestone</Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          <div className="space-y-4">
            {milestones.map(milestone => (
              <Card key={milestone.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center space-x-2">
                      <CheckCircle className={cn(
                        "h-5 w-5",
                        milestone.isCompleted ? "text-green-600" : "text-gray-400"
                      )} />
                      <span className={milestone.isCompleted ? "line-through" : ""}>
                        {milestone.title}
                      </span>
                    </CardTitle>
                    <Badge variant="outline">
                      {milestone.targetDate.toLocaleDateString()}
                    </Badge>
                  </div>
                  <CardDescription>{milestone.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-sm text-gray-600">
                    {milestone.tasks.length} tasks associated
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="calendar" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle>Calendar</CardTitle>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border"
                />
              </CardContent>
            </Card>
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>
                  {selectedDate ? `Tasks for ${selectedDate.toLocaleDateString()}` : 'Select a date'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedDate && (
                  <div className="space-y-3">
                    {tasks
                      .filter(task => 
                        task.dueDate && 
                        task.dueDate.toDateString() === selectedDate.toDateString()
                      )
                      .map(task => (
                        <div key={task.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => toggleTaskStatus(task.id)}
                          >
                            {task.status === 'completed' ? (
                              <CheckCircle className="h-4 w-4 text-green-600" />
                            ) : (
                              <Circle className="h-4 w-4 text-gray-400" />
                            )}
                          </Button>
                          <div className="flex-1">
                            <p className="font-medium">{task.title}</p>
                            <p className="text-sm text-gray-600">{task.description}</p>
                          </div>
                          <Badge className={priorityColors[task.priority]}>
                            {task.priority}
                          </Badge>
                        </div>
                      ))}
                    {tasks.filter(task => 
                      task.dueDate && 
                      task.dueDate.toDateString() === selectedDate.toDateString()
                    ).length === 0 && (
                      <p className="text-gray-500 text-center py-8">
                        No tasks scheduled for this date
                      </p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}