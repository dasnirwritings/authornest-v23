"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/auth-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BookOpen, Eye, EyeOff, Loader2, Building, Shield, Users } from 'lucide-react';
import Link from 'next/link';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [loginType, setLoginType] = useState<'tenant' | 'admin' | 'super'>('tenant');
  const [tenantSubdomain, setTenantSubdomain] = useState('');
  
  const { login, user } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (user) {
      router.push('/');
    }
  }, [user, router]);

  useEffect(() => {
    // Auto-detect tenant from subdomain
    if (typeof window !== 'undefined') {
      const hostname = window.location.hostname;
      const parts = hostname.split('.');
      
      if (parts.length > 2 && parts[0] !== 'www') {
        setTenantSubdomain(parts[0]);
        setLoginType('tenant');
      }
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await login(email, password, loginType === 'tenant' ? tenantSubdomain : undefined);
      router.push('/');
    } catch (err: any) {
      setError(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const getLoginTitle = () => {
    switch (loginType) {
      case 'super':
        return 'Super Admin Login';
      case 'admin':
        return 'SaaS Admin Login';
      case 'tenant':
        return tenantSubdomain ? `${tenantSubdomain} Portal Login` : 'Tenant Portal Login';
      default:
        return 'Login';
    }
  };

  const getLoginIcon = () => {
    switch (loginType) {
      case 'super':
        return <Shield className="h-8 w-8 text-red-600" />;
      case 'admin':
        return <Building className="h-8 w-8 text-blue-600" />;
      case 'tenant':
        return <Users className="h-8 w-8 text-purple-600" />;
      default:
        return <BookOpen className="h-8 w-8 text-purple-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Logo and Title */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
              <BookOpen className="text-white h-8 w-8" />
            </div>
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Author Portal</h1>
            <p className="text-gray-600">Multi-tenant SaaS Platform</p>
          </div>
        </div>

        <Card className="shadow-xl border-0">
          <CardHeader className="space-y-4">
            <div className="flex items-center justify-center space-x-3">
              {getLoginIcon()}
              <CardTitle className="text-xl">{getLoginTitle()}</CardTitle>
            </div>
            <CardDescription className="text-center">
              {loginType === 'tenant' && tenantSubdomain
                ? `Sign in to your ${tenantSubdomain} workspace`
                : 'Enter your credentials to access the platform'
              }
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Login Type Selector */}
            {!tenantSubdomain && (
              <Tabs value={loginType} onValueChange={(value) => setLoginType(value as any)}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="tenant" className="text-xs">
                    <Users className="h-3 w-3 mr-1" />
                    Tenant
                  </TabsTrigger>
                  <TabsTrigger value="admin" className="text-xs">
                    <Building className="h-3 w-3 mr-1" />
                    Admin
                  </TabsTrigger>
                  <TabsTrigger value="super" className="text-xs">
                    <Shield className="h-3 w-3 mr-1" />
                    Super
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            )}

            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {loginType === 'tenant' && !tenantSubdomain && (
                <div className="space-y-2">
                  <Label htmlFor="subdomain">Tenant Subdomain</Label>
                  <Input
                    id="subdomain"
                    type="text"
                    placeholder="your-company"
                    value={tenantSubdomain}
                    onChange={(e) => setTenantSubdomain(e.target.value)}
                    required
                  />
                  <p className="text-xs text-gray-500">
                    Enter your company's subdomain (e.g., "acme" for acme.authorportal.com)
                  </p>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  'Sign In'
                )}
              </Button>
            </form>

            <div className="space-y-4">
              <div className="text-center">
                <Link
                  href="/forgot-password"
                  className="text-sm text-purple-600 hover:text-purple-700 hover:underline"
                >
                  Forgot your password?
                </Link>
              </div>

              {loginType === 'tenant' && (
                <div className="text-center space-y-2">
                  <p className="text-sm text-gray-600">Don't have an account?</p>
                  <Link
                    href="/register"
                    className="text-sm text-purple-600 hover:text-purple-700 hover:underline font-medium"
                  >
                    Sign up for free
                  </Link>
                </div>
              )}
            </div>

            {/* Demo Credentials */}
            <div className="bg-gray-50 p-3 rounded-lg">
              <p className="text-xs text-gray-600 font-medium mb-2">Demo Credentials:</p>
              <div className="text-xs text-gray-500 space-y-1">
                <p>Email: admin@example.com</p>
                <p>Password: password</p>
                {loginType === 'tenant' && <p>Subdomain: example</p>}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center text-sm text-gray-500">
          <p>© 2024 Author Portal. All rights reserved.</p>
          <div className="flex justify-center space-x-4 mt-2">
            <Link href="/privacy" className="hover:text-gray-700">Privacy</Link>
            <Link href="/terms" className="hover:text-gray-700">Terms</Link>
            <Link href="/support" className="hover:text-gray-700">Support</Link>
          </div>
        </div>
      </div>
    </div>
  );
}