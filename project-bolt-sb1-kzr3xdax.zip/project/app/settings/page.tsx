"use client";

import { useState } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import {
  Settings,
  Globe,
  Palette,
  Shield,
  Bell,
  Users,
  CreditCard,
  Database,
  Mail,
  Smartphone,
  Lock,
  Eye,
  EyeOff,
  Save,
  Upload,
  Trash2,
  Plus,
  ExternalLink,
} from 'lucide-react';

const timezones = [
  'UTC',
  'America/New_York',
  'America/Chicago',
  'America/Denver',
  'America/Los_Angeles',
  'Europe/London',
  'Europe/Paris',
  'Europe/Berlin',
  'Asia/Tokyo',
  'Asia/Shanghai',
  'Australia/Sydney',
];

const languages = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Spanish' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'it', name: 'Italian' },
  { code: 'pt', name: 'Portuguese' },
  { code: 'ja', name: 'Japanese' },
  { code: 'ko', name: 'Korean' },
  { code: 'zh', name: 'Chinese' },
];

const currencies = [
  { code: 'USD', name: 'US Dollar', symbol: '$' },
  { code: 'EUR', name: 'Euro', symbol: '€' },
  { code: 'GBP', name: 'British Pound', symbol: '£' },
  { code: 'JPY', name: 'Japanese Yen', symbol: '¥' },
  { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$' },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$' },
];

const websiteTemplates = [
  { id: 'default', name: 'Default', description: 'Clean and professional template' },
  { id: 'modern', name: 'Modern', description: 'Contemporary design with animations' },
  { id: 'minimal', name: 'Minimal', description: 'Simple and elegant layout' },
  { id: 'creative', name: 'Creative', description: 'Bold and artistic design' },
];

export default function SettingsPage() {
  const { user, tenant } = useAuth();
  const [activeTab, setActiveTab] = useState('portal');
  const [settings, setSettings] = useState(tenant?.settings || {});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      // Mock API call to save settings
      await new Promise(resolve => setTimeout(resolve, 1000));
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (error) {
      console.error('Failed to save settings:', error);
    } finally {
      setSaving(false);
    }
  };

  const updateSetting = (path: string, value: any) => {
    setSettings(prev => {
      const keys = path.split('.');
      const updated = { ...prev };
      let current = updated;
      
      for (let i = 0; i < keys.length - 1; i++) {
        if (!current[keys[i]]) current[keys[i]] = {};
        current = current[keys[i]];
      }
      
      current[keys[keys.length - 1]] = value;
      return updated;
    });
  };

  if (!user || !tenant) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
          <p className="text-gray-600 mt-1">Manage your workspace configuration</p>
        </div>
        <div className="flex items-center space-x-2">
          {saved && (
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              Settings saved successfully
            </Badge>
          )}
          <Button onClick={handleSave} disabled={saving}>
            {saving ? (
              <>
                <Save className="h-4 w-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </>
            )}
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="portal" className="flex items-center space-x-2">
            <Settings className="h-4 w-4" />
            <span className="hidden sm:inline">Portal</span>
          </TabsTrigger>
          <TabsTrigger value="website" className="flex items-center space-x-2">
            <Globe className="h-4 w-4" />
            <span className="hidden sm:inline">Website</span>
          </TabsTrigger>
          <TabsTrigger value="branding" className="flex items-center space-x-2">
            <Palette className="h-4 w-4" />
            <span className="hidden sm:inline">Branding</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center space-x-2">
            <Shield className="h-4 w-4" />
            <span className="hidden sm:inline">Security</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center space-x-2">
            <Bell className="h-4 w-4" />
            <span className="hidden sm:inline">Notifications</span>
          </TabsTrigger>
          <TabsTrigger value="users" className="flex items-center space-x-2">
            <Users className="h-4 w-4" />
            <span className="hidden sm:inline">Users</span>
          </TabsTrigger>
        </TabsList>

        {/* Portal Settings */}
        <TabsContent value="portal" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Portal Configuration</CardTitle>
              <CardDescription>
                Configure basic settings for your workspace
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="portalName">Portal Name</Label>
                  <Input
                    id="portalName"
                    value={settings.portalName || ''}
                    onChange={(e) => updateSetting('portalName', e.target.value)}
                    placeholder="My Company Portal"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="timezone">Timezone</Label>
                  <Select
                    value={settings.timezone || 'UTC'}
                    onValueChange={(value) => updateSetting('timezone', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {timezones.map(tz => (
                        <SelectItem key={tz} value={tz}>{tz}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="language">Language</Label>
                  <Select
                    value={settings.language || 'en'}
                    onValueChange={(value) => updateSetting('language', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {languages.map(lang => (
                        <SelectItem key={lang.code} value={lang.code}>
                          {lang.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="currency">Currency</Label>
                  <Select
                    value={settings.currency || 'USD'}
                    onValueChange={(value) => updateSetting('currency', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencies.map(curr => (
                        <SelectItem key={curr.code} value={curr.code}>
                          {curr.symbol} {curr.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">User Management</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Allow User Registration</Label>
                      <p className="text-sm text-gray-500">Let users sign up for accounts</p>
                    </div>
                    <Switch
                      checked={settings.allowUserRegistration || false}
                      onCheckedChange={(checked) => updateSetting('allowUserRegistration', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Require Email Verification</Label>
                      <p className="text-sm text-gray-500">Users must verify their email</p>
                    </div>
                    <Switch
                      checked={settings.requireEmailVerification || false}
                      onCheckedChange={(checked) => updateSetting('requireEmailVerification', checked)}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="maxUsers">Maximum Users</Label>
                  <Input
                    id="maxUsers"
                    type="number"
                    value={settings.maxUsers || 100}
                    onChange={(e) => updateSetting('maxUsers', parseInt(e.target.value))}
                    min="1"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Website Settings */}
        <TabsContent value="website" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Website Configuration</CardTitle>
              <CardDescription>
                Configure your public website settings and subdomain
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Enable Website</Label>
                  <p className="text-sm text-gray-500">
                    Create a public website for your organization
                  </p>
                </div>
                <Switch
                  checked={settings.website?.enabled || false}
                  onCheckedChange={(checked) => updateSetting('website.enabled', checked)}
                />
              </div>

              {settings.website?.enabled && (
                <div className="space-y-6">
                  <Alert>
                    <Globe className="h-4 w-4" />
                    <AlertDescription>
                      Your website will be available at: <strong>{tenant.subdomain}.authorportal.com</strong>
                      {tenant.customDomain && (
                        <span> and <strong>{tenant.customDomain}</strong></span>
                      )}
                    </AlertDescription>
                  </Alert>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="websiteTitle">Website Title</Label>
                      <Input
                        id="websiteTitle"
                        value={settings.website?.title || ''}
                        onChange={(e) => updateSetting('website.title', e.target.value)}
                        placeholder="My Company"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="websiteTemplate">Template</Label>
                      <Select
                        value={settings.website?.template || 'default'}
                        onValueChange={(value) => updateSetting('website.template', value)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {websiteTemplates.map(template => (
                            <SelectItem key={template.id} value={template.id}>
                              <div>
                                <div className="font-medium">{template.name}</div>
                                <div className="text-sm text-gray-500">{template.description}</div>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="websiteDescription">Description</Label>
                    <Textarea
                      id="websiteDescription"
                      value={settings.website?.description || ''}
                      onChange={(e) => updateSetting('website.description', e.target.value)}
                      placeholder="Tell visitors about your organization..."
                      rows={3}
                    />
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">SEO Settings</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="metaTitle">Meta Title</Label>
                        <Input
                          id="metaTitle"
                          value={settings.website?.seoSettings?.metaTitle || ''}
                          onChange={(e) => updateSetting('website.seoSettings.metaTitle', e.target.value)}
                          placeholder="Page title for search engines"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="keywords">Keywords</Label>
                        <Input
                          id="keywords"
                          value={settings.website?.seoSettings?.keywords || ''}
                          onChange={(e) => updateSetting('website.seoSettings.keywords', e.target.value)}
                          placeholder="keyword1, keyword2, keyword3"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="metaDescription">Meta Description</Label>
                      <Textarea
                        id="metaDescription"
                        value={settings.website?.seoSettings?.metaDescription || ''}
                        onChange={(e) => updateSetting('website.seoSettings.metaDescription', e.target.value)}
                        placeholder="Brief description for search engines..."
                        rows={2}
                      />
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Custom Domain</h3>
                    <div className="space-y-2">
                      <Label htmlFor="customDomain">Custom Domain</Label>
                      <div className="flex space-x-2">
                        <Input
                          id="customDomain"
                          value={tenant.customDomain || ''}
                          placeholder="www.yourcompany.com"
                          disabled
                        />
                        <Button variant="outline">
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Configure
                        </Button>
                      </div>
                      <p className="text-sm text-gray-500">
                        Contact support to set up a custom domain for your website
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Branding Settings */}
        <TabsContent value="branding" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Branding & Appearance</CardTitle>
              <CardDescription>
                Customize the look and feel of your workspace
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Logo</Label>
                    <div className="flex items-center space-x-4">
                      <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                        {settings.branding?.logo ? (
                          <img src={settings.branding.logo} alt="Logo" className="w-full h-full object-cover rounded-lg" />
                        ) : (
                          <Upload className="h-6 w-6 text-gray-400" />
                        )}
                      </div>
                      <div className="space-y-2">
                        <Button variant="outline" size="sm">
                          <Upload className="h-4 w-4 mr-2" />
                          Upload Logo
                        </Button>
                        {settings.branding?.logo && (
                          <Button variant="outline" size="sm" className="text-red-600">
                            <Trash2 className="h-4 w-4 mr-2" />
                            Remove
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Favicon</Label>
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-gray-100 rounded flex items-center justify-center">
                        {settings.branding?.favicon ? (
                          <img src={settings.branding.favicon} alt="Favicon" className="w-full h-full object-cover rounded" />
                        ) : (
                          <Upload className="h-4 w-4 text-gray-400" />
                        )}
                      </div>
                      <Button variant="outline" size="sm">
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Favicon
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="primaryColor">Primary Color</Label>
                    <div className="flex space-x-2">
                      <Input
                        id="primaryColor"
                        type="color"
                        value={settings.branding?.primaryColor || '#6366f1'}
                        onChange={(e) => updateSetting('branding.primaryColor', e.target.value)}
                        className="w-16 h-10 p-1"
                      />
                      <Input
                        value={settings.branding?.primaryColor || '#6366f1'}
                        onChange={(e) => updateSetting('branding.primaryColor', e.target.value)}
                        placeholder="#6366f1"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="secondaryColor">Secondary Color</Label>
                    <div className="flex space-x-2">
                      <Input
                        id="secondaryColor"
                        type="color"
                        value={settings.branding?.secondaryColor || '#8b5cf6'}
                        onChange={(e) => updateSetting('branding.secondaryColor', e.target.value)}
                        className="w-16 h-10 p-1"
                      />
                      <Input
                        value={settings.branding?.secondaryColor || '#8b5cf6'}
                        onChange={(e) => updateSetting('branding.secondaryColor', e.target.value)}
                        placeholder="#8b5cf6"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="theme">Theme</Label>
                    <Select
                      value={settings.theme || 'light'}
                      onValueChange={(value) => updateSetting('theme', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="light">Light</SelectItem>
                        <SelectItem value="dark">Dark</SelectItem>
                        <SelectItem value="auto">Auto</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="customCSS">Custom CSS</Label>
                <Textarea
                  id="customCSS"
                  value={settings.branding?.customCSS || ''}
                  onChange={(e) => updateSetting('branding.customCSS', e.target.value)}
                  placeholder="/* Add your custom CSS here */"
                  rows={6}
                  className="font-mono text-sm"
                />
                <p className="text-sm text-gray-500">
                  Add custom CSS to further customize your workspace appearance
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Settings */}
        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>
                Configure security policies and authentication settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Authentication</h3>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Two-Factor Authentication</Label>
                    <p className="text-sm text-gray-500">Require 2FA for all users</p>
                  </div>
                  <Switch
                    checked={settings.security?.twoFactorAuth || false}
                    onCheckedChange={(checked) => updateSetting('security.twoFactorAuth', checked)}
                  />
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Password Policy</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="minLength">Minimum Length</Label>
                    <Input
                      id="minLength"
                      type="number"
                      value={settings.security?.passwordPolicy?.minLength || 8}
                      onChange={(e) => updateSetting('security.passwordPolicy.minLength', parseInt(e.target.value))}
                      min="6"
                      max="32"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="sessionTimeout">Session Timeout (minutes)</Label>
                    <Input
                      id="sessionTimeout"
                      type="number"
                      value={settings.sessionTimeout || 30}
                      onChange={(e) => updateSetting('sessionTimeout', parseInt(e.target.value))}
                      min="5"
                      max="1440"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <Label>Require Uppercase</Label>
                    <Switch
                      checked={settings.security?.passwordPolicy?.requireUppercase || false}
                      onCheckedChange={(checked) => updateSetting('security.passwordPolicy.requireUppercase', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Require Lowercase</Label>
                    <Switch
                      checked={settings.security?.passwordPolicy?.requireLowercase || false}
                      onCheckedChange={(checked) => updateSetting('security.passwordPolicy.requireLowercase', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Require Numbers</Label>
                    <Switch
                      checked={settings.security?.passwordPolicy?.requireNumbers || false}
                      onCheckedChange={(checked) => updateSetting('security.passwordPolicy.requireNumbers', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Require Symbols</Label>
                    <Switch
                      checked={settings.security?.passwordPolicy?.requireSymbols || false}
                      onCheckedChange={(checked) => updateSetting('security.passwordPolicy.requireSymbols', checked)}
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Session Security</h3>
                <div className="space-y-2">
                  <Label htmlFor="maxSessions">Maximum Concurrent Sessions</Label>
                  <Input
                    id="maxSessions"
                    type="number"
                    value={settings.security?.sessionSecurity?.maxSessions || 5}
                    onChange={(e) => updateSetting('security.sessionSecurity.maxSessions', parseInt(e.target.value))}
                    min="1"
                    max="20"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Settings */}
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>
                Configure how users receive notifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Mail className="h-5 w-5 text-blue-600" />
                    <div>
                      <Label>Email Notifications</Label>
                      <p className="text-sm text-gray-500">Send notifications via email</p>
                    </div>
                  </div>
                  <Switch
                    checked={settings.notifications?.emailNotifications || false}
                    onCheckedChange={(checked) => updateSetting('notifications.emailNotifications', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Bell className="h-5 w-5 text-green-600" />
                    <div>
                      <Label>Push Notifications</Label>
                      <p className="text-sm text-gray-500">Browser push notifications</p>
                    </div>
                  </div>
                  <Switch
                    checked={settings.notifications?.pushNotifications || false}
                    onCheckedChange={(checked) => updateSetting('notifications.pushNotifications', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Smartphone className="h-5 w-5 text-purple-600" />
                    <div>
                      <Label>SMS Notifications</Label>
                      <p className="text-sm text-gray-500">Text message notifications</p>
                    </div>
                  </div>
                  <Switch
                    checked={settings.notifications?.smsNotifications || false}
                    onCheckedChange={(checked) => updateSetting('notifications.smsNotifications', checked)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Users Settings */}
        <TabsContent value="users" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>User Management</CardTitle>
              <CardDescription>
                Manage users and their permissions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium">Current Usage</h3>
                  <p className="text-sm text-gray-500">
                    You have 5 active users out of {settings.maxUsers || 100} allowed
                  </p>
                </div>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Invite User
                </Button>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">User Limit</span>
                  <span className="text-sm text-gray-600">5 / {settings.maxUsers || 100}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-purple-600 h-2 rounded-full"
                    style={{ width: `${(5 / (settings.maxUsers || 100)) * 100}%` }}
                  />
                </div>
              </div>

              <Alert>
                <Users className="h-4 w-4" />
                <AlertDescription>
                  Need more users? <Link href="/billing" className="text-purple-600 hover:underline">Upgrade your plan</Link> to increase your user limit.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}