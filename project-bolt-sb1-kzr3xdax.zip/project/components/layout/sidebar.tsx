"use client";

import { useState } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
  LayoutDashboard,
  Calendar,
  FolderOpen,
  Globe,
  Megaphone,
  TrendingUp,
  BookOpen,
  Settings,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Eye,
  Plus,
  FileText,
  Users,
  Building,
  Dna,
  MapPin,
  Network,
  Image,
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const navigation = [
  { name: 'Dashboard', icon: LayoutDashboard, href: '/dashboard' },
  { name: 'Planning', icon: Calendar, href: '/planning' },
  { 
    name: 'Project', 
    icon: FolderOpen, 
    href: '/project',
    children: [
      { name: 'View Projects', icon: Eye, href: '/project/view' },
      { name: 'Create Project', icon: Plus, href: '/project/create' },
      { name: 'Published Projects', icon: FileText, href: '/project/published' },
      { type: 'separator' },
      { name: 'Characters', icon: Users, href: '/project/characters' },
      { name: 'Organisations', icon: Building, href: '/project/organisations' },
      { name: 'Species', icon: Dna, href: '/project/species' },
      { name: 'Locations', icon: MapPin, href: '/project/locations' },
      { name: 'Relations', icon: Network, href: '/project/relations' },
      { name: 'Images', icon: Image, href: '/project/images' },
    ]
  },
  { name: 'ARC Hub', icon: Globe, href: '/arc-hub' },
  { name: 'Publishing', icon: Megaphone, href: '/publishing' },
  { name: 'Marketing', icon: TrendingUp, href: '/marketing' },
  { name: 'Resources', icon: BookOpen, href: '/resources' },
  { name: 'Settings', icon: Settings, href: '/settings' },
];

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [activeItem, setActiveItem] = useState('Dashboard');
  const [expandedItems, setExpandedItems] = useState<string[]>([]);
  const [isCollapsed, setIsCollapsed] = useState(false);

  const toggleExpanded = (itemName: string) => {
    setExpandedItems(prev => 
      prev.includes(itemName) 
        ? prev.filter(item => item !== itemName)
        : [...prev, itemName]
    );
  };
  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed left-0 top-0 h-full bg-white border-r border-gray-200 transition-all duration-300 ease-in-out z-50',
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0',
          isCollapsed ? 'w-16' : 'w-64'
        )}
      >
        <div className="flex flex-col h-full">
          {/* Sidebar header */}
          <div className="p-4 border-b border-gray-200 flex items-center justify-between">
            {!isCollapsed && (
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                  <BookOpen className="text-white h-4 w-4" />
                </div>
                <span className="font-bold text-lg text-gray-900">Author Portal</span>
              </div>
            )}
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsCollapsed(!isCollapsed)}
              className="hidden lg:flex"
            >
              {isCollapsed ? (
                <ChevronRight className="h-4 w-4" />
              ) : (
                <ChevronLeft className="h-4 w-4" />
              )}
            </Button>
          </div>

          {/* Navigation */}
          <ScrollArea className="flex-1 px-3 py-4">
            <nav className="space-y-2">
              {navigation.map((item) => {
                const Icon = item.icon;
                const isActive = activeItem === item.name;
                const isExpanded = expandedItems.includes(item.name);
                const hasChildren = item.children && item.children.length > 0;
                
                if (hasChildren && !isCollapsed) {
                  return (
                    <Collapsible key={item.name} open={isExpanded} onOpenChange={() => toggleExpanded(item.name)}>
                      <CollapsibleTrigger asChild>
                        <Button
                          variant={isActive ? "secondary" : "ghost"}
                          className={cn(
                            "w-full justify-between h-11 px-3",
                            isActive && "bg-purple-50 text-purple-700 hover:bg-purple-100"
                          )}
                          onClick={() => setActiveItem(item.name)}
                        >
                          <div className="flex items-center">
                            <Icon className="h-5 w-5 mr-3" />
                            <span className="truncate">{item.name}</span>
                          </div>
                          <ChevronDown className={cn(
                            "h-4 w-4 transition-transform",
                            isExpanded && "rotate-180"
                          )} />
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="space-y-1 mt-1">
                        {item.children.map((child, index) => {
                          if (child.type === 'separator') {
                            return <div key={index} className="h-px bg-gray-200 mx-3 my-2" />;
                          }
                          
                          const ChildIcon = child.icon;
                          const isChildActive = activeItem === child.name;
                          
                          return (
                            <Button
                              key={child.name}
                              variant={isChildActive ? "secondary" : "ghost"}
                              className={cn(
                                "w-full justify-start h-9 px-6 text-sm",
                                isChildActive && "bg-purple-50 text-purple-700 hover:bg-purple-100"
                              )}
                              onClick={() => setActiveItem(child.name)}
                            >
                              <ChildIcon className="h-4 w-4 mr-3" />
                              <span className="truncate">{child.name}</span>
                            </Button>
                          );
                        })}
                      </CollapsibleContent>
                    </Collapsible>
                  );
                }
                
                return (
                  <Button
                    key={item.name}
                    variant={isActive ? "secondary" : "ghost"}
                    className={cn(
                      "w-full justify-start h-11 px-3",
                      isActive && "bg-purple-50 text-purple-700 hover:bg-purple-100",
                      isCollapsed && "justify-center px-2"
                    )}
                    onClick={() => setActiveItem(item.name)}
                  >
                    <Icon className={cn("h-5 w-5", !isCollapsed && "mr-3")} />
                    {!isCollapsed && (
                      <span className="truncate">{item.name}</span>
                    )}
                  </Button>
                );
              })}
            </nav>
          </ScrollArea>

          {/* Sidebar footer */}
          <div className="p-4 border-t border-gray-200">
            {!isCollapsed && (
              <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-3 rounded-lg">
                <p className="text-sm font-medium text-gray-900">Upgrade to Pro</p>
                <p className="text-xs text-gray-600 mt-1">
                  Unlock unlimited projects & advanced writing tools
                </p>
                <Button className="w-full mt-2 h-8 text-xs">
                  Upgrade Now
                </Button>
              </div>
            )}
          </div>
        </div>
      </aside>
    </>
  );
}