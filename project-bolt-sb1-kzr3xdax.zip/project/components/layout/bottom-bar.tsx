"use client";

import { useState } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  LayoutDashboard,
  Calendar,
  FolderOpen,
  Settings,
} from 'lucide-react';

const bottomNavigation = [
  { name: 'Dashboard', icon: LayoutDashboard, href: '/dashboard' },
  { name: 'Planning', icon: Calendar, href: '/planning' },
  { name: 'Project', icon: FolderOpen, href: '/project' },
  { name: 'Settings', icon: Settings, href: '/settings' },
];

export function BottomBar() {
  const [activeItem, setActiveItem] = useState('Dashboard');

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 md:hidden z-50">
      <div className="flex justify-around items-center py-2">
        {bottomNavigation.map((item) => {
          const Icon = item.icon;
          const isActive = activeItem === item.name;
          
          return (
            <Button
              key={item.name}
              variant="ghost"
              size="sm"
              className={cn(
                "flex flex-col items-center space-y-1 h-auto py-2 px-3",
                isActive && "text-blue-600"
              )}
              onClick={() => setActiveItem(item.name)}
            >
              <Icon className="h-5 w-5" />
              <span className="text-xs truncate">{item.name}</span>
            </Button>
          );
        })}
      </div>
    </div>
  );
}