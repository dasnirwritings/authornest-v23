"use client";

import { createContext, useContext, useEffect, useState } from 'react';
import { User, Tenant, AuthContextType, RegisterData } from '@/types/auth';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Initialize auth state
    checkAuthState();
  }, []);

  const checkAuthState = async () => {
    try {
      // Check for stored auth token
      const token = localStorage.getItem('auth_token');
      const tenantSubdomain = getTenantFromSubdomain();
      
      if (token) {
        // Validate token and get user data
        const userData = await validateToken(token, tenantSubdomain);
        if (userData) {
          setUser(userData.user);
          setTenant(userData.tenant);
        }
      }
    } catch (error) {
      console.error('Auth check failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const getTenantFromSubdomain = (): string | null => {
    if (typeof window === 'undefined') return null;
    
    const hostname = window.location.hostname;
    const parts = hostname.split('.');
    
    // Check if it's a subdomain (not localhost or main domain)
    if (parts.length > 2 && parts[0] !== 'www') {
      return parts[0];
    }
    
    return null;
  };

  const validateToken = async (token: string, tenantSubdomain?: string | null) => {
    // Mock API call - replace with actual API
    return new Promise<{ user: User; tenant: Tenant } | null>((resolve) => {
      setTimeout(() => {
        // Mock validation
        if (token === 'valid_token') {
          resolve({
            user: {
              id: '1',
              email: 'user@example.com',
              firstName: 'John',
              lastName: 'Doe',
              role: 'tenant_admin',
              tenantId: 'tenant_1',
              isActive: true,
              createdAt: new Date(),
              updatedAt: new Date(),
            },
            tenant: {
              id: 'tenant_1',
              name: 'Example Company',
              subdomain: tenantSubdomain || 'example',
              timezone: 'UTC',
              language: 'en',
              currency: 'USD',
              subscriptionId: 'sub_1',
              settings: {
                portalName: 'Example Portal',
                timezone: 'UTC',
                language: 'en',
                currency: 'USD',
                dateFormat: 'MM/DD/YYYY',
                timeFormat: '12h',
                theme: 'light',
                allowUserRegistration: true,
                requireEmailVerification: true,
                sessionTimeout: 30,
                maxUsers: 100,
                features: ['projects', 'notes', 'collaboration'],
                branding: {
                  primaryColor: '#6366f1',
                  secondaryColor: '#8b5cf6',
                },
                website: {
                  enabled: false,
                  template: 'default',
                  customPages: [],
                  seoSettings: {},
                },
                notifications: {
                  emailNotifications: true,
                  pushNotifications: true,
                  smsNotifications: false,
                },
                security: {
                  twoFactorAuth: false,
                  passwordPolicy: {
                    minLength: 8,
                    requireUppercase: true,
                    requireLowercase: true,
                    requireNumbers: true,
                    requireSymbols: false,
                  },
                  sessionSecurity: {
                    maxSessions: 5,
                    ipWhitelist: [],
                  },
                },
              },
              isActive: true,
              createdAt: new Date(),
              updatedAt: new Date(),
            },
          });
        } else {
          resolve(null);
        }
      }, 1000);
    });
  };

  const login = async (email: string, password: string, tenantSubdomain?: string) => {
    setLoading(true);
    try {
      // Mock login API call
      const response = await mockLogin(email, password, tenantSubdomain);
      
      if (response.success) {
        localStorage.setItem('auth_token', response.token);
        setUser(response.user);
        setTenant(response.tenant);
      } else {
        throw new Error(response.message);
      }
    } catch (error) {
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    localStorage.removeItem('auth_token');
    setUser(null);
    setTenant(null);
  };

  const register = async (userData: RegisterData) => {
    setLoading(true);
    try {
      // Mock registration API call
      const response = await mockRegister(userData);
      
      if (response.success) {
        localStorage.setItem('auth_token', response.token);
        setUser(response.user);
        setTenant(response.tenant);
      } else {
        throw new Error(response.message);
      }
    } catch (error) {
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const updateProfile = async (data: Partial<User>) => {
    if (!user) return;
    
    try {
      // Mock update API call
      const updatedUser = { ...user, ...data, updatedAt: new Date() };
      setUser(updatedUser);
    } catch (error) {
      throw error;
    }
  };

  const mockLogin = async (email: string, password: string, tenantSubdomain?: string) => {
    return new Promise<any>((resolve) => {
      setTimeout(() => {
        if (email === 'admin@example.com' && password === 'password') {
          resolve({
            success: true,
            token: 'valid_token',
            user: {
              id: '1',
              email,
              firstName: 'John',
              lastName: 'Doe',
              role: 'tenant_admin',
              tenantId: 'tenant_1',
              isActive: true,
              createdAt: new Date(),
              updatedAt: new Date(),
            },
            tenant: {
              id: 'tenant_1',
              name: 'Example Company',
              subdomain: tenantSubdomain || 'example',
              timezone: 'UTC',
              language: 'en',
              currency: 'USD',
              subscriptionId: 'sub_1',
              settings: {
                portalName: 'Example Portal',
                timezone: 'UTC',
                language: 'en',
                currency: 'USD',
                dateFormat: 'MM/DD/YYYY',
                timeFormat: '12h',
                theme: 'light',
                allowUserRegistration: true,
                requireEmailVerification: true,
                sessionTimeout: 30,
                maxUsers: 100,
                features: ['projects', 'notes', 'collaboration'],
                branding: {
                  primaryColor: '#6366f1',
                  secondaryColor: '#8b5cf6',
                },
                website: {
                  enabled: false,
                  template: 'default',
                  customPages: [],
                  seoSettings: {},
                },
                notifications: {
                  emailNotifications: true,
                  pushNotifications: true,
                  smsNotifications: false,
                },
                security: {
                  twoFactorAuth: false,
                  passwordPolicy: {
                    minLength: 8,
                    requireUppercase: true,
                    requireLowercase: true,
                    requireNumbers: true,
                    requireSymbols: false,
                  },
                  sessionSecurity: {
                    maxSessions: 5,
                    ipWhitelist: [],
                  },
                },
              },
              isActive: true,
              createdAt: new Date(),
              updatedAt: new Date(),
            },
          });
        } else {
          resolve({
            success: false,
            message: 'Invalid credentials',
          });
        }
      }, 1000);
    });
  };

  const mockRegister = async (userData: RegisterData) => {
    return new Promise<any>((resolve) => {
      setTimeout(() => {
        resolve({
          success: true,
          token: 'valid_token',
          user: {
            id: '2',
            email: userData.email,
            firstName: userData.firstName,
            lastName: userData.lastName,
            role: 'tenant_user',
            tenantId: userData.tenantId || 'tenant_1',
            isActive: true,
            createdAt: new Date(),
            updatedAt: new Date(),
          },
          tenant: {
            id: 'tenant_1',
            name: 'Example Company',
            subdomain: 'example',
            timezone: 'UTC',
            language: 'en',
            currency: 'USD',
            subscriptionId: 'sub_1',
            settings: {
              portalName: 'Example Portal',
              timezone: 'UTC',
              language: 'en',
              currency: 'USD',
              dateFormat: 'MM/DD/YYYY',
              timeFormat: '12h',
              theme: 'light',
              allowUserRegistration: true,
              requireEmailVerification: true,
              sessionTimeout: 30,
              maxUsers: 100,
              features: ['projects', 'notes', 'collaboration'],
              branding: {
                primaryColor: '#6366f1',
                secondaryColor: '#8b5cf6',
              },
              website: {
                enabled: false,
                template: 'default',
                customPages: [],
                seoSettings: {},
              },
              notifications: {
                emailNotifications: true,
                pushNotifications: true,
                smsNotifications: false,
              },
              security: {
                twoFactorAuth: false,
                passwordPolicy: {
                  minLength: 8,
                  requireUppercase: true,
                  requireLowercase: true,
                  requireNumbers: true,
                  requireSymbols: false,
                },
                sessionSecurity: {
                  maxSessions: 5,
                  ipWhitelist: [],
                },
              },
            },
            isActive: true,
            createdAt: new Date(),
            updatedAt: new Date(),
          },
        });
      }, 1000);
    });
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        tenant,
        loading,
        login,
        logout,
        register,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}